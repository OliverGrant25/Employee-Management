﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using finals_practice.AppData;
namespace finals_practice
{
    public partial class FrmRegister : Form
    {
        private UserRepository userRepo;
        finalstest10Entities db;


        public FrmRegister()
        {
            InitializeComponent();
            //
            userRepo = new UserRepository();
            db = new finalstest10Entities();
        }

        private void FrmRegister_Load(object sender, EventArgs e)
        {
            loadCbBoxRole();
        }

        public void loadCbBoxRole()
        { 
            // Selecting roles

            var roles = db.Roles.ToList();


            cbBoxRole.DataSource = roles;
            cbBoxRole.ValueMember = "roleId";
            cbBoxRole.DisplayMember = "roleType";
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            FrmLogin login = new FrmLogin();
            login.ShowDialog();

            //FrmRegister register = new FrmRegister();
            //register.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtUsername.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtUsername, "Empty Field!");
                return;
            }

            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtPassword, "Empty Field!");
                return;
            }

            if (String.IsNullOrEmpty(txtFirstname.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtFirstname, "Empty Field!");
                return;
            }

            if (String.IsNullOrEmpty(txtLastname.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtLastname, "Empty Field!");
                return;
            }

            if (String.IsNullOrEmpty(txtEmail.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtEmail, "Empty Field!");
                return;
            }

            if (String.IsNullOrEmpty(txtAddress.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(txtAddress, "Empty Field!");
                return;
            }

            errorProvider.Clear();

            //Calling the function userRepo
            ErrorCode res = userRepo.FrmRegister(txtFirstname.Text, txtLastname.Text, txtUsername.Text, txtPassword.Text, txtAddress.Text, txtEmail.Text);
            if (res == ErrorCode.Success)
            {
                //Clear textboxes
                txtUsername.Clear();
                txtPassword.Clear();
                txtFirstname.Clear();
                txtLastname.Clear();
                txtEmail.Clear();
                txtAddress.Clear();

                //messsage prompt
                MessageBox.Show("Successfully Registered!");
            }
            else
            {
                MessageBox.Show("Error Registration!");
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }
    }
}
