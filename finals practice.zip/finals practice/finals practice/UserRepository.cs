﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using finals_practice.AppData;


namespace finals_practice
{
    public enum ErrorCode
    { 
        Error,
        Success
    }
    public class UserRepository
    {
        public ErrorCode FrmRegister(String FirstName, String Lastname, String Email, String Address, String username, String password)
        {
            try
            {
                using (var db = new finalstest10Entities())
                {
                    var userInfo = new userInformation();
                    var userAcc = new userAcc();

                    userInfo.userInFname = FirstName;
                    userInfo.userInLname = Lastname;
                    userInfo.userInEmail = Email;
                    userInfo.userInAddress = Address;
                    userAcc.username = username;
                    userAcc.userPassword = password;

                    db.userInformation.Add(userInfo);
                    db.userAcc.Add(userAcc);
                    db.SaveChanges();

                    return ErrorCode.Success;
                }
                
            }
            catch (Exception ex) 
            {
                Console.WriteLine("Error " + ex.Message);
                return ErrorCode.Error;
            }
        }
    }
}
